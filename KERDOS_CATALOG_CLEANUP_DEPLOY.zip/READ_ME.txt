KERDOS CATALOG CLEANUP — October 3, 2026
Based on current GitHub main 788d9a8. Includes the already-deployed Case/Each pack change.

INCLUDED
1. Restaurant unit menus: Case, Each, LB, OZ, GAL, QT, PT, FL OZ, KG, G, L, ML, Dozen. No length units or vocabulary duplicate entries. Quoted per and Details use the same choices; import quote choices are consistent too. Existing unusual imported units are retained for review rather than silently changed. Other industries retain their unit options.
2. Restaurant Produce means fresh only. Dried/powdered, preserved, frozen and prepared forms use an available appropriate category, falling back to General. Existing conflicting placements receive accuracy warnings, rather than silently overwriting past manual choices. No new categories or client/vendor-specific rules were added.
3. Editable KERDOS number in the catalog spreadsheet. Enter another EXISTING KERDOS number and Apply changes to associate this vendor listing with that catalog item. Row corrections and association save atomically. Links remain subject to product/brand/pack checks. A manual number does not mean 100% accurate. The destination name/category and other vendors remain intact; vendor item numbers are unchanged. No duplicate vendor listing is created. Changing the association does not remove the old catalog item.

DEPLOY IN THIS ORDER
1. Open KERDOS_CATALOG_LINK_UPDATE.sql and paste its ENTIRE contents into Supabase SQL Editor. Run it. This is an UPDATE, not a data reset, and requires the previous database migrations already deployed.
2. Unzip KERDOS_CATALOG_CLEANUP_DEPLOY.zip.
3. In GitHub open the repository ROOT (where package.json lives). Upload the extracted src, knowledge, and scripts FOLDERS plus KERDOS_DATABASE_UPDATE_CLEAN.sql. Preserve these paths. Do not upload src's contents at the root, and do not upload into root-level pages/core folders.
4. Commit, wait for green Actions, refresh KERDOS using Shift + Command + R.

The knowledge migration is also kept in the repo for future builds. The root combined SQL has been regenerated; you do not need to run that full combined update now, only the short catalog-link update supplied separately.

VERIFY
- Quoted per dropdown has no yards/meters/feet/inches for Restaurant.
- Pack remains Case/Each with Each count 1.
- Import granulated garlic or sun-dried tomatoes: category is not Produce.
- In Item Catalog, enter an existing KERDOS number belonging to a comparable item. The destination name appears; Apply changes saves the association. Reload and verify both vendor listings share the number. Different brands, packs or product details still show evidence warnings.
- Apply name/category changes before changing an association; those fields belong to the shared catalog item, while product/brand/pack/price are vendor-row fields.

VALIDATION
Full existing test suite (including added unit, category, tenant-boundary, atomic rollback, stale-edit and linking checks), lint and production build passed. Live deployment has not been run by Codex.
